#-*- coding: UTF-8 -*-

import os
import sys
import re
import pyinotify
import time
import threading
import asyncio

import wsl_run
import setting as ENV

# 监听结果返回线程
RTNLISTENTHREAD = None
LISTENTHREAD = None
monitor_loop=None

# 监听目录
filepath = ENV.LOCAL_RSYNC_ALL

filelist = []
resultlist = []

'''
listeninfo = {
    'id' : 0,
    'event' : '',
    'filename' : '',
    'filepath' : ''
}
'''


def now_time():
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())

#----------------------
# 监听事件类
#----------------------

def listening(self, event, message):
    try:
        listeninfo = {}
        listeninfo['id'] = message['tag']
        listeninfo['event'] = (now_time() + message['msg'])
        listeninfo['filepath'] = event.pathname
        listeninfo['filename'] = event.pathname.split('/')[-1]
        if not listeninfo['filename'].isdigit():
            if not re.search("swp",listeninfo['filename']):
                if not re.search("swx",listeninfo['filename']):
                    if not ENV.LISTENING:
                        ENV.LISTENING.append(listeninfo)
                    if not ENV.LISTENING[-1]['filename'] == listeninfo['filename']:
                        if len(ENV.LISTENING) > ENV.LISTENING_LEN:
                            return 0
                        ENV.LISTENING.append(listeninfo)
    except Exception as e:
        print (now_time() + e)

class MyEventHandler(pyinotify.ProcessEvent):

    def process_IN_ACCESS(self, event):
        """
        文件被访问
        :param event:
       :return:
        """
        return 0
        message = {}
        message['tag'] = 1
        message['msg'] = "文件被访问"
        listening(self, event, message)

    def process_IN_ATTRIB(self, event):
        """
        文件属性被修改，如chmod、chown、touch等
        :param event:
        :return:
        """
        return 0
        message = {}
        message['tag'] = 2
        message['msg'] = "文件属性被修改"
        listening(self, event, message)        

    def process_IN_CLOSE_NOWRITE(self, event):
        """
        不可写文件被close
        :param event:
        :return:
        """
        return 0
        message = {}
        message['tag'] = 3
        message['msg'] = "不可写文件被close"
        listening(self, event, message)

    def process_IN_CLOSE_WRITE(self, event):
        """
        可写文件被close
        :param event:
        :return: rsync -av /etc/passwd  192.168.204.168:/tmp/passwd.txt
        """
        return 0
        message = {}
        message['tag'] = 4
        message['msg'] = "可写文件被close"
        listening(self, event, message)

    def process_IN_CREATE(self, event):
        """
        创建新文件
        :param event:
        :return:
        """
        return 0
        message = {}
        message['tag'] = 5
        message['msg'] = "创建新文件"
        listening(self, event, message)

    def process_IN_DELETE(self, event):
        """
        文件被删除
        :param event:
        :return:
        """
        message = {}
        message['tag'] = 6
        message['msg'] = "文件被删除"
        #listening(self, event, message)
        
        listeninfo = {}
        listeninfo['id'] = message['tag']
        listeninfo['event'] = (now_time() + message['msg'])
        listeninfo['filepath'] = event.pathname
        listeninfo['filename'] = event.pathname.split('/')[-1]
        if not listeninfo['filename'].isdigit():
            if not re.search("swp",listeninfo['filename']):
                if not re.search("swx",listeninfo['filename']):
                    if not ENV.LISTENING:
                        ENV.LISTENING.append(listeninfo)
                    if not ENV.LISTENING[-1]['filename'] == listeninfo['filename']:
                        if len(ENV.LISTENING) > ENV.LISTENING_LEN:
                            return 0
                        ENV.LISTENING.append(listeninfo)

    def process_IN_MODIFY(self, event):
        """
        文件被修改
        :param event:
        :return:
        """
        return 0
        message = {}
        message['tag'] = 7
        message['msg'] = "文件被修改"
        listening(self, event, message)

    def process_IN_OPEN(self, event):
        """
         文件被打开
        :param event:
        :return:
        """
        return 0
        message = {}
        message['tag'] = 8
        message['msg'] = "文件被打开"
        listening(self, event, message)

def get_file_dir(file_path, file_name):
    global filelist
    looplist = []
    if file_name == ENV.MAP2 or file_name == ENV.MAP1:
        if os.path.isdir(file_path):
            dirs = os.listdir(file_path)
            for item in dirs:
                if os.path.isdir(file_path + '/' + item):
                    get_file_dir(file_path + '/' + item, file_name)
                else:
                    looplist.append(item)
    else:
        if os.path.isdir(file_path):
            dirs = os.listdir(file_path)
            for item in dirs:
                if item == ENV.MAP2 or item == ENV.MAP1:
                    file_name = item
                    get_file_dir(file_path + file_name, file_name)
    filelist.append(looplist)
    return (filelist)

#------------------------
# kao , mei yong dao
#------------------------
def chaifen_list(list_s):
    global resultlist
    if isinstance(list_s, list):
        for item in list_s:
            if isinstance(item, list):
                chaifen_list(item)
            resultlist.append(item)
    return resultlist

#-------------------------------------
# start listen and rtnlisten thread
#-------------------------------------
def start():
    global RTNLISTENTHREAD
    global LISTENTHREAD
    try:
        LISTENTHREAD = ListenThread('LISTENTHREAD')
        LISTENTHREAD.start()
        time.sleep(0.5)
        RTNLISTENTHREAD = RtnListenThread('RTNLISTENTHREAD')
        RTNLISTENTHREAD.start()
    except:
        print (now_time() + "THREAD START FAILED\n")

#------------------------------
# stop rtnlisten thread
# 问题：监听线程无法正常停止
#------------------------------
def stop():
    global RTNLISTENTHREiAD
    global LISTENTHREAD
    global monitor_loop
    try:
        #print (' LISTENING IS %s \n' %ENV.LISTENING)
        #print ('RTN IS %s \n' %ENV.RTN_LISTEN)
        if RTNLISTENTHREAD:
            RTNLISTENTHREAD._RtnListenThread__running.clear()
        if LISTENTHREAD:
            if monitor_loop:
                monitor_loop.stop()
            LISTENTHREAD._ListenThread__running.clear()
    except:
        print (now_time() + "RTNLISTENTHREAD STOP FAILED\n")

#-------------------------
# 监听返回线程
#-------------------------
class RtnListenThread(threading.Thread):
    '''
    listenlist = 
    [{'id': 6, 'event': '2022-07-04 11:33:33文件被删除', 'filepath': '/mnt/d/Git/Gerrit/ODSP/DK-MGMT/DK-MGMT/ODSP/login/sessiondataprocess.py~', 'filename': 'sessiondataprocess.py~'}, {'id': 6, 'event': '2022-07-04 11:33:44文件被删除', 'filepath': '/mnt/d/Git/Gerrit/ODSP/DK-MGMT/DK-MGMT/ODSP/login/login.py~', 'filename': 'login.py~'}]
    '''
    def __init__ (self, threadname):
        try:
            threading.Thread.__init__(self, name=threadname)
            self.__running = threading.Event()
            self.__running.set()
        except:
            print (now_time() + "rtnlistenthread init failed\n")

    def run(self):
        global filepath
        while self.__running.isSet():
            try:
                time.sleep(0.5)
                rtndata = {}
                listenlist = ENV.LISTENING
                # TODO 处理监听返回列表
                if True:
                    if listenlist:
                        for listen_file in listenlist:
                            if not listen_file['id']:
                                break
                            if listen_file['id'] == 2 or listen_file['id'] == 7:
                                rtndata['filename'] = listen_file['filename']
                                rtndata['filepath'] = listen_file['filepath']
                            elif listen_file['id'] == 6:
                                rtndata['filename'] = listen_file['filename']
                                rtndata['filepath'] = listen_file['filepath']
                            if rtndata:
                                if not ENV.RTN_LISTEN:
                                    ENV.RTN_LISTEN.append(rtndata)
                                else:
                                    i = 0
                                    for rtn_listen_file in ENV.RTN_LISTEN:
                                        if rtn_listen_file == rtndata:
                                            break
                                        else:
                                            i = i + 1
                                            if i == len(ENV.RTN_LISTEN):
                                                ENV.RTN_LISTEN.append(rtndata)
                                                break
                            if len(ENV.RTN_LISTEN) > ENV.RTN_LISTEN_LEN:
                                return 0
                else:
                    if isinstance(result, list):
                        for item in result:
                            if item:
                                if isinstance(item, list):
                                    for etim in item:
                                        # TODO etim = digilun.py or []
                                        #if etim = ?
                                        if listenlist:
                                            for listen_file in listenlist:
                                                if not listen_file['id']:
                                                    continue
                                                if listen_file['id'] == 2 or listen_file['id'] == 7:
                                                    rtndata['filename'] = listen_file['filename']
                                                    rtndata['filepath'] = listen_file['filepath']
                                                elif listen_file['id'] == 6:
                                                    rtndata['filename'] = listen_file['filename']
                                                    rtndata['filepath'] = listen_file['filepath']
                                                if rtndata:
                                                    if not ENV.RTN_LISTEN:
                                                        ENV.RTN_LISTEN.append(rtndata)
                                                    else:
                                                        ENV.RTN_LISTEN.append(rtndata)
                                                        #print (ENV.RTN_LISTEN)
                                                        if ENV.RTN_LISTEN[-1]['filename'] == ENV.RTN_LISTEN[-2]['filename']:
                                                            ENV.RTN_LISTEN.pop()
                                                if len(ENV.RTN_LISTEN) > ENV.RTN_LISTEN_LEN:
                                                    return 0
                                                #listen_deal()
                                                #time.sleep(0.5)
                                                #print (ENV.RTN_LISTEN)
                            else:
                                continue
                #listen_deal()
                #time.sleep(0.5)
            except:
                print (now_time() + "rtnlistenthread run failed\n")
            time.sleep(.1)

#-------------------------
# 监听线程
#-------------------------
class ListenThread(threading.Thread):
    def __init__ (self, threadname):
        try:
            threading.Thread.__init__(self, name=threadname)
            self.__running = threading.Event()
            self.__running.set()
        except:
            print (now_time() + "listenthread init failed\n")

    def run(self):
        try:
            if self.__running.isSet():
                global monitor_loop
                monitor_obj = pyinotify.WatchManager()
                monitor_obj.add_watch(ENV.LOCAL_RSYNC_ALL, pyinotify.ALL_EVENTS, rec=True)
                event_handler= MyEventHandler()
                monitor_loop= pyinotify.ThreadedNotifier(monitor_obj, event_handler)
                monitor_loop.start()

        except Exception as e:
            print (now_time() + "listenthread run failed\n")

#----------------------
# 处理监听返回列表
#----------------------
def listen_deal():
    try:
        wsl_run.rsync_listener(1)
        wsl_run.rsync_toserver()
    except Exception as e:
        print (now_time() + "listen_deal error\n")

#-----------------------------
# 监听服务总程序
#-----------------------------
# if __name__ == '__main__':
def listen_main(params=None):
    if not params:
        stop()
        return 0
    start()

