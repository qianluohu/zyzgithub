#-*- coding: UTF-8 -*-

import os
import sys
import re
import paramiko
import tarfile
import time
import threading
import asyncio

import listener
import setting as ENV

ssh_client = None
sftp = None
transport = None

rsync_flag = 0

def ssh_client_con():
    global ssh_client 
    ssh_client = paramiko.SSHClient()
    ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy)
    ssh_client.connect(port = ENV.port, hostname = ENV.RSYNC_LINUXIP, username = ENV.user_name, password = ENV.password)

def transport_file():
    global sftp
    global transport
    transport = paramiko.Transport((ENV.RSYNC_LINUXIP, ENV.port))
    transport.connect(username=ENV.user_name, password=ENV.password)
    sftp = paramiko.SFTPClient.from_transport(transport)

def test():
    ssh_client_con()
    stdin, stdout, stderr = ssh_client.exec_command('hostname && rm -rf /tmp/remotetar.tar.gz')
    result = stdout.read().strip().decode()
    if result:
        print ("connect ok\n")
        ssh_client.close()

def rsync_listener(params):
    global rsync_flag
    if params:
        rsync_flag = 1
    return rsync_flag
    


# 拷贝对应代码至/usr/local/
def deal_tar(params1, localfile1, localfile2):
    global rsync_flag
    if params1:
        rsync_flag = 0
        return 0
    else:
        ssh_client_con()
        stdin, stdout, stderr = ssh_client.exec_command('cd /tmp/ && tar -xvf remotetar.tar.gz')
        time.sleep(1)
        stdin, stdout, stderr = ssh_client.exec_command('cd /tmp/ && cp -r %s %s && cp -r %s %s' %(localfile1, ENV.MAP_REMOTE_DIR, localfile2, ENV.MAP_REMOTE_DIR))
        result = stdout.read().strip().decode()
        if not result:
            print ("deal ok\n")
            ssh_client.close()

#------------------------------------------------------------
# 拷贝文件到远端
#   *** 如果实时更新检测出文件差异，则只更新发生变化的文件，
#   否则全部更新
#   *** SFTP不支持目录传送
#       本地将目录压缩成tar包，再调用deal_tar()处理即可
#------------------------------------------------------------
def rsync_toserver():
    global rsync_flag
    transport_file()
    if rsync_flag:
        '''
        RTN_LISTEN = 
        [{'filename': 'perafcsan.py~', 'filepath': '/mnt/d/Git/Gerrit/DK/DK-MGMT/DK-MGMT/ODSP/san/perafcsan.py~'}, {'filename': 'ReadMe~', 'filepath': '/mnt/d/Git/Gerrit/DK/DK-MGMT/DK-MGMT/ODSP/ReadMe~'}, {'filename': 'digilun.py~', 'filepath': '/mnt/d/Git/Gerrit/DK/DK-MGMT/DK-MGMT/ODSP/storpoollun/digilun.py~'}, {'filename': 'main.py~', 'filepath': '/mnt/d/Git/Gerrit/DK/DK-MGMT/DK-MGMT/ODSP/main.py~'}]
        '''
        if ENV.RTN_LISTEN:
            for rsync_info in ENV.RTN_LISTEN:
                print (rsync_info['filepath'][:-1])
                rsync_single(rsync_info['filepath'][:-1], 1)
        transport.close()
        # TODO 作废
        '''
        if ENV.RTN_LISTEN[0]['filepath']:
            if not ENV.RTN_LISTEN[1]['filepath']:
                rsync_file = ENV.RTN_LISTEN[0]['filepath']
                rsync_name = ENV.RTN_LISTEN[0]['filename']
            rsync_file = ENV.RTN_LISTEN[1]['filepath']
            rsync_name = ENV.RTN_LISTEN[1]['filename']
            result = sftp.put(rsync_file,'/tmp/%s' %rsync_name)
            if not result:
                print ('put failed\n')
                return 0
        transport.close()
        deal_tar(rsync_flag,ENV.RTN_LISTEN[1]['filepath'],'')
        '''
    else:
        # 全量同步
        localtar = tarfile.open('localtar.tar.gz', 'w')
        # 将代码目录路径重命名方便后续拷贝
        # 例：/mnt/d/Git/Gerrit/ODSP/DK-MGMT/DK-MGMT/ODSP -> ODSP
        add_dir1 = ENV.MAP2
        add_dir2 = ENV.MAP1
        localtar.add(ENV.LOCAL_RSYNC[ENV.MAP2], arcname=add_dir1)
        localtar.add(ENV.LOCAL_RSYNC[ENV.MAP1], arcname=add_dir2)
        localtar.close()
        result = sftp.put('/mnt/d/A-Samba_Windows/rsync_winandlinux/localtar.tar.gz','/tmp/remotetar.tar.gz')
        if not result:
            print ('put failed\n')
            return 0
        transport.close()
        deal_tar(rsync_flag, add_dir1, add_dir2)

def rsync_toclient():
    print ("nothing\n")

def restart_odspd():
    ssh_client_con()
    stdin, stdout, stderr = ssh_client.exec_command('systemctl restart odspd')
    print ("Please wait 5s \n")
    time.sleep(5)
    result = stdout.read().strip().decode()
    if result:
        print ("restart odspd ok\n")
        ssh_client.close()

def restart_httpd():
    ssh_client_con()
    stdin, stdout, stderr = ssh_client.exec_command('systemctl restart httpd')
    print ("Please wait 5s \n")
    time.sleep(5)
    result = stdout.read().strip().decode()
    if result:
        print ("restart httpd ok\n")
        ssh_client.close()

'''
def rsync_listener_2():
    try:
        listener_thread = threading.Thread(target=listener.run_listener,args=())
        deal_listen_thread = threading.Thread(target=listener.deal_listen,args=())
        listener_thread.start()
        deal_listen_thread.start()

    except Exception as e:
        print (now_time() + "Process error",e)
'''

#-------------------
# 单文件同步
#  tip : 0, 手动模式 1, 实时自动模式
#-------------------
def rsync_single(file_path, tip):
    while True:
        if not file_path:
            print ("@--@***********************************@--@ \n")
            print ("1. 请输入需要同步文件的绝对路径：\n")
            print ("2. 退出同步 \n")
            file_path = input()
            if not file_path:
                print ("Params Error!\n")
            elif file_path == '2':
                print ("Thanks! \n")
                break
        # rsync
        transport_file()
        # -------------- 
        #file_path : /mnt/d/Git/Gerrit/DK/DK-MGMT/DK-MGMT/ODSP/storpool/digilun.py
        # remote_map_file : digilun.py
        # remote_file_path : /usr/local 
        # map_origin_path :
        remote_map_file = file_path.split('/')[-1]
        remote_file_path = ''
        map_origin_path = ''
        if re.search(ENV.MAP2, file_path):
            map_origin_path = ENV.MAP2
            # TODO  正则式请依据实际
            remote_file_path = re.findall(r'(?<=ODSP).*$', file_path)
        elif re.search(ENV.MAP1, file_path):
            map_origin_path = ENV.MAP1
            remote_file_path = re.findall(r'(?<=digitools).*$', file_path)
        for item in remote_file_path:
            remote_file_path = item
        if remote_file_path:
            remote_file_path = re.sub(file_path.split('/')[-1], '', remote_file_path)
        remote_map_file_path = ENV.MAP_REMOTE_DIR + map_origin_path + remote_file_path
        result = sftp.put(file_path,'/tmp/%s' %remote_map_file)
        if not result:
            print ('put failed\n')
            transport.close()
            break
        transport.close()
        ssh_client_con()
        stdin, stdout, stderr = ssh_client.exec_command('cd /tmp/ && cp -r %s %s/' %(remote_map_file, remote_map_file_path))
        result = stdout.read().strip().decode()
        if not result:
            ssh_client.close()
            print ("本次同步成功！\n")
            if tip:
                break
            file_path = None


def main():
    while True:
        flag = 0
        print ("*----------------------------------------------*\n")
        print ("请输入您的选择：\n")
        print ("*-- 0. 实时监控文件更新 \n")
        print ("*-- 1. 测试连接 \n")
        print ("*-- 2. 同步代码(覆盖测试机) \n")
        print ("*-- 3. 同步指定文件(覆盖测试机) \n")
        print ("*-- 4. 同步代码(覆盖本地)   \n")
        print ("*-- 5. 重启远端服务1(odspd) \n")
        print ("*-- 6. 重启远端服务2(httpd) \n")
        print ("*-- 7. 退出 \n")
        print ("*----------------------------------------------*\n")
        chose = input()
        if chose:
            if chose == '0':
                while True:
                    print ('''
                        监听返回事件当且仅当文件被【:wq】执行后才会触发；
                        文件修改上限：50
                        输入 exit 退出监听并同步所有改动文件\n''')
                    listener.listen_main(1)
                    listen_tip = input()
                    if listen_tip == 'exit':
                        print ('请耐心等待同步成功\n')
                        listener.listen_deal()
                        print ("Listening exit success\n")
                        break
            if chose == '1':
                test()
            if chose == '2':
                rsync_toserver()
            if chose == '3':
                rsync_single(None, 0)
            if chose == '4':
                rsync_toclient()
            if chose == '5':
                restart_odspd()
            if chose == '6':
                restart_httpd()
            if chose == '7':
                listener.listen_main(0)
                print ("Thanks for use\n")
                flag = 1
                break
    if (flag != 1):
        print ("have failed\n")

if __name__ == '__main__':
    main()





