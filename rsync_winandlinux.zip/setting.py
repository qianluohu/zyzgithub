#-*- coding: utf-8 -*-
import os
import sys
import queue

# *------------------------
# 1. 本地目录与远端目录配置
# 2. 本地IP与远端IP配置
# 3. 监听配置
# *------------------------

#-----------------------------------------------------------------------------------------------------------
# 1. 目录

# 主要映射目录
MAP1 = 'digitools'
MAP2 = 'ODSP'
# 远端映射头目录
'''
 映射与映射头的关系就是拷贝时将映射目录下拷贝到远端映射头目录对应位置下
'''
MAP_REMOTE_DIR = '/usr/local/'

#本地同步目录
LOCAL_RSYNC = {
    MAP1 : '/mnt/d/Git/Gerrit/DK/DK-MGMT/DK-MGMT/digitools',
    MAP2 : '/mnt/d/Git/Gerrit/DK/DK-MGMT/DK-MGMT/ODSP'
}
# 测试服务器同步目录
REMOTE_RSYNC = {
    MAP1 : '/usr/local/digitools',
    MAP2 : '/usr/local/ODSP'
}
#-----------------------------------------------------------------------------------------------------------

# 2. IP与端口

#测试服务器IP[hostname]
RSYNC_LINUXIP = '192.168.4.97'
#windows IP
RSYNC_WINIP = '192.168.4.233'
#测试服务器连接端口与口令
user_name = 'root'
port = 9999
password = 'asdf'
#-----------------------------------------------------------------------------------------------------------

# 3. 实时监控

LOOP = False
# 监听总目录
LOCAL_RSYNC_ALL = '/mnt/d/Git/Gerrit/DK/DK-MGMT/DK-MGMT/'
# 监听列表
LISTENING = []
LISTENING_LEN = 10000
# 监听返回
RTN_LISTEN = []
RTN_LISTEN_LEN = 50
RTNLISTENQUEUE = queue.Queue(2)
