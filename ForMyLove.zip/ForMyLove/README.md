# coding = utf-8
# 声明 : 特别感谢arunboy, xuyuanzhi from Github
# author : zyz

打开方式：
  运行index.html
  搜索框输入自己的名字



images
#----------------------------
lover.jpg 换成喜欢的人的图片

love/
#----------------------------
故事情节请自行补充
lovebgm.mp3 自行更换

