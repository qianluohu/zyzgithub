Please obey blibli classes practise and turn to 可使用
Now please turn to pythonProject_reptileTest and read Readme.txt
last projectover turn to flask_reptileTest 

Of course if you wouldn't to learn course turn to 可直接使用
just execute __init__.py

尚且存在的问题：
1. 打开程序执行的网页后，不输入用户信息也能通过点击底部 Submit Request 获取到数据，这显然是不合法的
2. 去向电影地址的超链接IP异常
3. 对于前端页面的设计并不算合理