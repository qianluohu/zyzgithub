from flask import Flask,render_template,request
import datetime

app = Flask(__name__)

# @app.route('/')                                 # 路由解析，匹配函数，注意：路由路径不能重复
# def hello_world():
#     return 'Hello zyz!'

@app.route('/index')
def hello():
    return "nice"                                 # 发现了吗？/index对于前端是个入口，hello()对于后端是个入口

@app.route('/login/<username>')                   # 前台手打username，观察效果
def login(username):
    return "Hello , User %s"%username

@app.route('/user/<int:id>')
def loginnu(id):
    return "Hello %d号会员！"%id

@app.route('/xuanran')
def xuanran():
    time = datetime.date.today()
    name = ["小张","小王","小赵"]
    task = {"任务":"打扫卫生","时间":"3小时"}
    return render_template("old_index.html",var = time,list = name , task = task)

# 表单提交
@app.route('/test/register')
def register():
    return render_template('test/register.html')
@app.route('/result',methods = ['POST','GET'])                                        # result界面应由/test/register跳转而来，在接收表单时应制定接收的方法：get either post
def result():
    if request.method == 'POST':
        result = request.form
    return render_template('test/result.html',result=result)

if __name__ == '__main__':
    app.run(debug=True)                         # Debug模式默认 off，开启后，我们对本地的修改会实时更新到服务器前台