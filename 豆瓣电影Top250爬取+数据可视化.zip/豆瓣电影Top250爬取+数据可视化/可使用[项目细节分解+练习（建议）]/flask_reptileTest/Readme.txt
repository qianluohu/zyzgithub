from：https://www.bilibili.com/video/BV12E411A7ZQ
author：zyz
图标资源：https://www.iconfont.cn/
注意：先完成项目 pythonProject_reptileTest

使用手册：
run app.py
click bottom "Submit Request"

本项目只用到了一个html页面，如果想做多个html跳转，只需要copy index.html，重命名后删除不需要的内容，并在app.py中添加路由即可
after copy htmlsource
                      .html to templates/
                      /assets to static/
   after replace all projects 'assets*' in 'static/assets*'
   after change app.py
