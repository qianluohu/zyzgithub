import sqlite3
'''
Pycharm社区版没有database环境，需要在【setting -- plugin -- install Database Nevigator】
此外，Sqlite3 DB Browser是单线程操作，可能会在多次插入时提示"数据库被锁定"错误
'''
# conn = sqlite3.connect("test.db")  # sqlite3所有文件视作表单
# print("Opened database successfully")
# c = conn.cursor()
# sql = '''
# create table company
#     (id int not null primary key autoincrement,
#     name text not null,
#     age int not null,
#     address char(50),
#     salary real);
#
# '''
# c.execute(sql)
# conn.commit()
# conn.close()
# print("Build table successfully")
#
# # 插入数据
# conn = sqlite3.connect("test.db")  # sqlite3所有文件视作表单
# # print("Opened database successfully")
# c = conn.cursor()
# sql = '''
# insert into company (id,name,age,address,salary)
# values (3,'王五',20,'北京',1000)
#
# '''
# c.execute(sql)
# conn.commit()
# conn.close()
# print("插入完毕")
#查询数据

# sql = "select id,name,address,salary from company"
# cursor = c.execute(sql)
# for row in cursor:
#     print("id = ",row[0])
#     print("name = ",row[1])
#     print("address = ",row[2])
#     print("salary = ",row[3],"\n")
# conn.close()