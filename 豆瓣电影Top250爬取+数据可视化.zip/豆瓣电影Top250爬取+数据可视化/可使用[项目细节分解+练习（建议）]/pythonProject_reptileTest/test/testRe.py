import re

# # 创建模式对象
# pat = re.compile("AA")  # AA: 正则表达式标准
# m = pat.search("CNDAA")
# n = pat.search("CNMDSAAAKJAA")
# print(n)
#
# # 简化模式
# m = re.search("AA","addcAAs")
# n = re.findall("AA","sdfvsdfdAAdfdAA")
# l = re.findall("[A-Z]+","sdfvsdfdAAdfdAA")
# print(n)

# sub 替换
m = re.sub("a","A","aaaabc")
print(m)