import urllib.request

# try:
#     response = urllib.request.urlopen("http://httpbin.org/get",timeout = 5)   # get不需要传参, post需要
#     print(response.read().decode('utf-8'))
# except urllib.error.URLError as e:
#     print("time out!")

# response = urllib.request.urlopen("http://www.baidu.com")
# print(response.getheader("Server"))

# url = "https://httpbin.org/post"
# headers = {
#     'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36'
# }
# data = bytes(urllib.parse.urlencode({'name':'eric'}),encoding = "utf-8")
# req = urllib.request.Request(url = url,data = data ,headers = headers,method = "POST")
# response = urllib.request.urlopen(req)
# print(response.read().decode("utf-8"))

# url = "https://www.douban.com"
# headers = {
#     'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36'
# }
# req = urllib.request.Request(url = url,headers = headers)
# response = urllib.request.urlopen(req)
# print(response.read().decode("utf-8"))

# BeautifulSoup4 four objects：Tag , NavigableString , BeautifulSoup , Comment
from bs4 import BeautifulSoup
import re
file = open("./douban.html","rb")
html = file.read()
bs = BeautifulSoup(html,"html.parser")
#print(bs.a)
#print(bs.title) # Tag : 获取第一个符合定义名的标签全部内容
# print(bs.title.string) # NavigableString：标签中的字符串 , 有时某个String被添加了<!-- -->，此时该String被认定为 Comment类型
# print(bs.a.attrs)
# print(type(bs)) # BeautifulSoup

# file_foreach
print(bs.head.contents[1])

# file_lookup
def name_is_exists(tag):
    return tag.has_attr("name")
t_list1 = bs.find_all("a")  # (1) 精确匹配
t_list2 = bs.find_all(re.compile("a")) # (2) 正则表达式（模糊匹配）
t_list3 = bs.find_all(name_is_exists) # (3)
# print(t_list3)
# for item in t_list3:
#     print(item)
t_list4 = bs.find_all(id = "head",class_ = True)
t_list5 = bs.find_all(text = "肖申克的救赎")
# for item in t_list5:
#     print(item)
t_list6 = bs.find_all("a",limit = 3)

# css选择器
t_list7 = bs.select('title')
t_list8 = bs.select('.mnav')
t_list9 = bs.select('a[class="bri"]')
t_list10 = bs.select("head > title")
for item in t_list10:
    print(item)

