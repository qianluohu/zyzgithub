import os
import runpy
from time import sleep

import spider
import app

def main():
    spider.main()
    print("data have saved please wait a quarter")
    sleep(15)
    app.main()


if __name__ == "__main__":
    main()