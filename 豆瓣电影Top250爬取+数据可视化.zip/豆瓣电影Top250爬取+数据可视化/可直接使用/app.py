from flask import Flask,render_template,request
import sqlite3

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/index')
def home():
    return index()

@app.route('/showdata')                                       # 按理说展示【电影】【评分】【词云】界面应该是三个不同的html界面和两个路由函数，本项目为了方便将所有功能参数一次传递了
def movie():
    movielist = []
    con = sqlite3.connect("doubanmovie.db")
    cur = con.cursor()
    sql = "select * from movie250"
    data = cur.execute(sql)
    for item in data:
        movielist.append(item)
    if data != '':
        cur.close()
        con.close()
    else:
        cur.close()
        con.close()
    (moviescore,moviequantity) = showscore()
    return render_template('index.html', movies = movielist , moviescore = moviescore , moviequantity = moviequantity , img = showwordcloud())

def showscore():
    moviescore = []
    moviequantity = []
    con = sqlite3.connect("doubanmovie.db")
    cur = con.cursor()
    sql = "select score,count(score) from movie250 group by score"
    data = cur.execute(sql)
    for item in data:
        moviescore.append(item[0])
        moviequantity.append(item[1])
    if data != '':
        cur.close()
        con.close()
    else:
        cur.close()
        con.close()
    return (moviescore , moviequantity)

def showwordcloud():
    img = 'static/assets/img/wordcloud.jpg'
    return img

# @app.route('/showdata2')
# def socre():
#     moviescore = []
#     moviequantity = []
#     con = sqlite3.connect("doubanmovie.db")
#     cur = con.cursor()
#     sql = "select score,count(score) from movie250 group by score"
#     data = cur.execute(sql)
#     for item in data:
#         moviescore.append(item[0])
#         moviequantity.append(item[1])
#     if data != '':
#         cur.close()
#         con.close()
#     else:
#         cur.close()
#         con.close()
#     return render_template('index.html', moviescore = moviescore , moviequantity = moviequantity)
def main():
    app.run(debug=True)
if __name__ == '__main__':
    main()